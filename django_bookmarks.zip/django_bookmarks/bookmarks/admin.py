from django.contrib import admin

# Register your models here.
from .models import signup, investquery, ProjectName, Cust_Acc, Invest_detail, Ipp_Plan, Cdpp_Plan
admin.site.register(signup)
admin.site.register(investquery)
admin.site.register(ProjectName)
admin.site.register(Cust_Acc)
admin.site.register(Invest_detail)
admin.site.register(Ipp_Plan)
admin.site.register(Cdpp_Plan)




from .models import Bookmark

admin.site.register(Bookmark)

