from bookmarks.models import signup


# For authoritation of user

class auth_user :
    def __init__(self, username, password):
        self.username=username
        self.password=password

    def auth(self, username, password):
        signup_obj= signup.objects.get(userid = username)
        user = signup_obj.userid
        signup_obj2= signup.objects.get(password = password)
        password = signup_obj2.password

        if user == username and password == password :
            return True
        else:
            return False

if '__name__'=="__main__":
    pass


