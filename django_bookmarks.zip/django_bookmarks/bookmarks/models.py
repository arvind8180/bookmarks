from django.db import models

# Create your models here.

class signup(models.Model):

   fname = models.CharField(max_length = 50)
   lname = models.CharField(max_length = 50)
   userid = models.CharField(max_length=15)
   mail = models.CharField(max_length = 50)
   mnumber = models.IntegerField()
   password= models.CharField(max_length=12)

   def filldata(self, fname, lname, userid, mail, mnumber, password):

       self.fname = fname
       self.lname = lname
       self.userid = userid
       self.mail = mail
       self.mnumber = mnumber
       self.password = password
       self.save()


class Link(models.Model):
    url = models.URLField(unique=True)

from django.contrib.auth.models import User
class Bookmark(models.Model):
    title = models.CharField(max_length=200)
    user = models.ForeignKey(User)
    link = models.ForeignKey(Link)


class details(models.Model):
    name=models.CharField(max_length=100)


class investquery(models.Model):
    TIME_DURATION = (
        ('6', '6 Month'),
        ('12', '12 Month'),
        ('24', '24 Month'),
        ('36', '36 Month')
    )
    fname=models.CharField(max_length=20)
    lname=models.CharField(max_length=20)
    amount=models.IntegerField()
    age=models.SmallIntegerField()
    mobile=models.IntegerField()
    duration=models.IntegerField(choices=TIME_DURATION)


    def filldata(self, fname,lname, amount, age, mobile, duration):
        self.fname=fname
        self.lname=lname
        self.amount=amount
        self.age=age
        self.mobile=mobile
        self.duration=duration
        self.save()



## Models to add project details.
import datetime

class ProjectName(models.Model):
    pro_id=models.IntegerField(primary_key=True)
    company_name=models.CharField(max_length=30)
    location=models.CharField(max_length=50)
    pro_name=models.CharField(max_length=30)
    pro_type=models.CharField(max_length=20)
    num_flats=models.IntegerField()
    flat_size=models.IntegerField()
    rate=models.IntegerField()
    cont_person=models.CharField(max_length=20)
    #enroll_date=models.parse_datetime(datetime.time.hour)
    constract_status=models.CharField(max_length=20)
    #pro_pics=models.ImageField()

class Ipp_Plan(models.Model):
    plan_name=models.CharField(primary_key=True, max_length=50)
    plan_months= models.IntegerField()
    plan_rate=models.SmallIntegerField()

class Cdpp_Plan(models.Model):
    plan_name=models.CharField(primary_key=True, max_length=50)
    plan_months= models.IntegerField()
    plan_rate=models.SmallIntegerField()


class Cust_Acc(models.Model):
    signup=models.ForeignKey(signup, on_delete=models.CASCADE )
    acc_id=models.IntegerField(primary_key=True)
    ProjectName=models.ForeignKey(ProjectName, on_delete=models.CASCADE)
    invest_amt=models.IntegerField()
    Plan_name=models.ForeignKey(Ipp_Plan, on_delete=models.CASCADE)


class Invest_detail(models.Model):
    Cust_Acc=models.ForeignKey(Cust_Acc, on_delete=models.CASCADE)



















