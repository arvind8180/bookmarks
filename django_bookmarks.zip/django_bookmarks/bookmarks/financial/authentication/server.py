import socket
import threading

def client_man(c):
    counter=1
    counter += 1
    byteobject = 'this is Thread'+ str(counter)
    thread_list=[]
    byteobject = byteobject.encode('utf-8')
    thread_list = thread_list.append(byteobject)
    c.send(thread_list)
    c.close()  # Close the connection

s = socket.socket()  # Create a socket object
host = socket.gethostname()  # Get local machine name
port = 9000  # Reserve a port for your service.
s.bind((host, port))  # Bind to the port

s.listen(5)  # Now wait for client connection.
while True:
    c, addr = s.accept()  # Establish connection with client.
    threading.Thread(target=client_man, args=(c,))
    print ('Got connection from', addr)
