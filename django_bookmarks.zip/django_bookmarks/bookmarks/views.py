from django.shortcuts import render

# Create your views here.
from django.http import HttpResponse, Http404
import datetime
from bookmarks.models import signup
def index(request):
    text = """<h1>!!!!</h1>"""
    return HttpResponse(text)


def hello(request):
    today=datetime.datetime.now().date()
    return render(request, "index.html")

def sign(request):
    signup1= signup(
        fname="arvind",
        lname = "sharma",
        userid="arvind_sh",
        mail = "arvindsharma@gmail.com",
        mnumber = "9952005947",
        password = "arvind",
    )
    signup1.save()

from bookmarks.models import User, Bookmark, Link
from django.template.loader import get_template
from django.template import Context, loader
from django.core.context_processors import csrf
from django.shortcuts import render_to_response, render
from bookmarks.models import signup, investquery, Ipp_Plan, Cdpp_Plan
from bookmarks.financial.authentication import auth_cust

def user_page(request):
    userid=''
    global check

    if request.POST:

        user_id=request.POST['login']
        password=request.POST['password']


        check_data=auth_cust.auth_user(user_id, password)
        global check
        check = check_data.auth(user_id, password)


        if check:
            ref_cust= signup.objects.get(userid=user_id)
            ref_cust_id = int(ref_cust.id)
            request.session['member_id'] = ref_cust_id


            return render_to_response("index.html", {"userid": user_id, "session_state": request.session['member_id']})


    else:

        return render (request, "login_page.html")

    #output=template.render(variables)
    #return HttpResponse(output)

def user_logout(request):
    try:
        del request.session['member_id']
    except KeyError:
        pass
    return render_to_response("index.html")


def index(self):
    page=get_template('index.html')
    output=page.render(self)
    return HttpResponse(output)




def inquery(request):

    if request.POST:

        query1=investquery()
        query1.filldata(request.POST['fname'],request.POST['lname'],request.POST['amount'],request.POST['age'],request.POST['mobile'],request.POST['duration'] )
        amount=int(request.POST['amount'])
        duration=int(request.POST['duration'])
        calamt = ((12/100*amount)*duration)+amount
        return render(request, 'invest_query.html', {'amount': calamt})

    else:
        return render(request, 'invest_query.html')



    '''if request.POST:

        query1=investquery(
                fname='saurabh',
                lname='sharma',
                age='23',
                amount='1000',
                mobile='83828748845',
                duration='2')
        query1.save()
        amount = investquery.objects.get(fname='saurabh')

        return render(request, 'invest_query.html', {'amount': amount})

    else:

        return render(request, 'invest_query.html')'''



# To register a User :

def register_user(request):

    if request.POST and (request.POST['password'] == request.POST['re_password']):

        user_data=signup()
        user_data.filldata(request.POST['fname'], request.POST['lname'], request.POST['userid'], request.POST['mail'],
                        request.POST['mobile'], request.POST['password'])

        return render(request, "register.html",{'confirm_msg': request.POST['userid']} )

    else:
        return render(request, "register.html")



# Investmentpage

def invest_page(request):

    template =get_template("index.html")
    output=template.render()
    return HttpResponse(output)

## for client and server


import socket
import threading

def callback(request):
    print('You clicked the button!')



def clientside(request):

    global data, clnt, v
    s = socket.socket()  # Create a socket object
    host = socket.gethostname()  # Get local machine name
    port = 9000  # Reserve a port for your service.

    s.connect((host, port))
    while(True):
        fromclient = threading._allocate_lock
        fromclient = input('Enter string')
        fromclient = fromclient.encode('utf-8')
        s.send(fromclient)

        fromserver = s.recv(1024).decode('utf-8')
        print(fromserver)
        if fromserver == '':
            print("Connection closed from client side")
            break
        else:
            pass

    s.close()  # Close the socket when done
    return render_to_response("invest_query.html", {'amount' : 'arvind'})

def plan_page(request):
    ippdata = Ipp_Plan.objects.all()
    return render_to_response('planpage.html', {'plannames': ippdata})

def plan_confirm(request):
    if request.POST:
        plan= request.POST['plan']
        cust_id = int(request.session['member_id'])
        user_data = signup.objects.get(id=cust_id)
        userid = user_data.userid
        mail = user_data.mail
        fname = user_data.fname
        lname = user_data.lname
        amount = request.POST['amount']
        tenure = request.POST['tenure']
        mobile = request.POST['mobile']
        address = request.POST['address']
        plan_obj=Ipp_Plan.objects.get(plan_name=plan)
        int_rate_montly = (float(plan_obj.plan_rate)/12)
        amt_mat =((float(amount) * (int_rate_montly/100))*float(tenure)) + float(amount)

        return render_to_response("plan_confirm.html", {'amt_mat' : amt_mat, 'address': address, 'userid' : userid, 'mail' : mail, 'fname' : fname, 'lname' : lname, 'cust_id': cust_id })



    else:
        return render_to_response('plan_confirm.html')

def create_acc(request):
    pass

















